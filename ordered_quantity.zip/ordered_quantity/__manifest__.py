# -*- coding: utf-8 -*-
{
    'name': 'Ordered Quantity Products',
    'version': '17.0.1.0.0',
    'summary': 'Ordered Quantity Products Only',
    'description': 'Ordered Quantity Products Only',
    'category': "Sales",
    'depends': [
        'base',
        'sale',
    ],
    'data': [
        'views/res_parnter_views.xml',
        'views/sale_order_views.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}





