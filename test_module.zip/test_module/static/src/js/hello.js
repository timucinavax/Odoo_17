/** @odoo-module **/
import { Component, useState } from "@odoo/owl";

export class ChildComp extends Component {
    static template = "test_module.hello";
}
//registry.category("actions").add('hello_1',Title);
